# C/C++ 基础必修题参考实现

四道 C/C++ 基础题的参考代码。

| 文件 | 题目 | 考点 |
|------|------|------|
| readings.cpp | 读数统计 | 防溢出、min/max 初始化 |
| device.cpp | 设备巡检记录 | 结构体、过滤/统计/查询 |
| window.c | 固定容量读数窗口 | 环形缓冲防越界 |
| stats.h / stats.cpp / main.cpp / CMakeLists.txt | 多文件统计工具 | 头文件、实现、CMake |

## 编译运行

读数统计：

```
g++ -std=c++17 readings.cpp -o readings
```

设备巡检：

```
g++ -std=c++17 device.cpp -o device
```

窗口：

```
gcc window.c -o window
```

多文件（CMake）：

```
cmake -S . -B build
cmake --build build
./build/main
```
