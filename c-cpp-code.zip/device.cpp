#include <bits/stdc++.h>
using namespace std;

struct Device {
    string id;
    int status;
    double value;
};

vector<Device> filter_by_status(const vector<Device>& ds, int st) {
    vector<Device> r;
    for (auto& d : ds)
        if (d.status == st) r.push_back(d);
    return r;
}

double sum_value(const vector<Device>& ds) {
    double s = 0;
    for (auto& d : ds) s += d.value;
    return s;
}

Device* find_by_id(vector<Device>& ds, const string& id) {
    for (auto& d : ds)
        if (d.id == id) return &d;
    return nullptr;
}

int main() {
    vector<Device> ds = {
        {"A1", 1, 1.5},
        {"A2", 0, 2.5},
        {"A3", 1, 3.5}
    };
    auto on = filter_by_status(ds, 1);
    cout << "count=" << on.size() << " sum=" << sum_value(on) << "\n";
    Device* p = find_by_id(ds, "A2");
    if (p) cout << "found " << p->id << "\n";
    return 0;
}
