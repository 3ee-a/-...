#include <bits/stdc++.h>
#include "stats.h"
using namespace std;

int main() {
    vector<double> v;
    double x;
    while (cin >> x) v.push_back(x);
    cout << mean(v) << "\n";
    return 0;
}
