#include <bits/stdc++.h>
using namespace std;

int main() {
    long long n = 0, sum = 0;
    long long mn = LLONG_MAX, mx = LLONG_MIN;
    long long x;
    while (cin >> x) {
        ++n;
        sum += x;
        mn = min(mn, x);
        mx = max(mx, x);
    }
    if (n == 0) {
        cout << "0 0\n";
        return 0;
    }
    cout << n << " " << sum << " " << mn << " " << mx << "\n";
    return 0;
}
