#include <stdio.h>
#define CAP 8

static int win[CAP];
static int head = 0, count = 0;

void add_reading(int v) {
    win[head] = v;
    head = (head + 1) % CAP;
    if (count < CAP) count++;
}

void print_readings(void) {
    int start = (count < CAP) ? 0 : head;
    for (int i = 0; i < count; i++)
        printf("%d\n", win[(start + i) % CAP]);
}

int main(void) {
    int v;
    while (scanf("%d", &v) == 1) add_reading(v);
    print_readings();
    return 0;
}
